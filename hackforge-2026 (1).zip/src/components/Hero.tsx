import { motion } from 'motion/react';
import { Sparkles, Calendar, MapPin, Play, Clock } from 'lucide-react';

interface HeroProps {
  onRegisterClick: () => void;
}

export default function Hero({ onRegisterClick }: HeroProps) {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 px-4 md:px-8 overflow-hidden">
      {/* Background radial highlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-[#B9FF66]/5 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Texts Column (Left) */}
        <div className="lg:col-span-7 space-y-6 text-left">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2.5 bg-[#191A23] border-2 border-[#191A23] px-3.5 py-1.5 rounded-full"
          >
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#B9FF66] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#B9FF66]" />
            </span>
            <span className="text-xs font-mono font-bold text-white tracking-wider uppercase">
              Hacking Portal Open • October 23-25, 2026
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight leading-[1.05] text-[#191A23]"
          >
            Build. Break. <br /> Innovate.
            <div className="mt-2 text-2xl sm:text-3xl md:text-4xl block font-sans">
              Hack the Future in <span className="neo-highlight text-[#191A23]">48 Hours.</span>
            </div>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-[#191A23]/85 text-sm sm:text-md md:text-lg leading-relaxed max-w-2xl font-bold font-sans"
          >
            Join developers, designers, AI builders, and entrepreneurs for an intense weekend of innovation, collaboration, and real-world problem solving. Craft solutions with cutting-edge tools.
          </motion.p>

          {/* Quick specs pill tags */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="flex flex-wrap gap-3 pt-2"
          >
            <div className="flex items-center gap-1.5 bg-white border-2 border-[#191A23] px-3.5 py-1.5 rounded-xl text-xs font-bold text-[#191A23] font-mono shadow-[2.5px_2.5px_0px_#191A23]">
              <Calendar className="w-3.5 h-3.5 text-[#B9FF66] fill-[#191A23]" /> Oct 23-25, 2026
            </div>
            <div className="flex items-center gap-1.5 bg-white border-2 border-[#191A23] px-3.5 py-1.5 rounded-xl text-xs font-bold text-[#191A23] font-mono shadow-[2.5px_2.5px_0px_#191A23]">
              <MapPin className="w-3.5 h-3.5 text-[#B9FF66] fill-[#191A23]" /> Calicut, Kerala
            </div>
            <div className="flex items-center gap-1.5 bg-white border-2 border-[#191A23] px-3.5 py-1.5 rounded-xl text-xs font-bold text-[#191A23] font-mono shadow-[2.5px_2.5px_0px_#191A23]">
              <Clock className="w-3.5 h-3.5 text-[#B9FF66] fill-[#191A23]" /> 48h Sprint
            </div>
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4"
          >
            <button
              id="hero-register-btn"
              type="button"
              onClick={onRegisterClick}
              className="neo-btn px-8 py-4 text-center text-sm md:text-base uppercase flex items-center justify-center gap-2 cursor-pointer animate-bounce"
            >
              Register Now <Sparkles className="w-4.5 h-4.5 fill-black/10" />
            </button>
            <a
              id="hero-schedule-link"
              href="#schedule"
              className="neo-btn-black px-8 py-4 text-center text-sm md:text-base uppercase flex items-center justify-center gap-2 cursor-pointer"
            >
              View Schedule <Play className="w-4 h-4 fill-[#B9FF66] text-[#B9FF66]" />
            </a>
          </motion.div>

          {/* Miniature live stats ticker */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-3 gap-4 pt-10 max-w-xl border-t-2 border-[#191A23]/10"
          >
            <div>
              <div className="text-xl sm:text-2xl font-black text-[#191A23] font-mono bg-[#B9FF66] px-2 py-0.5 rounded-md border border-[#191A23] inline-block shadow-[1.5px_1.5px_0px_#191A23]">500+</div>
              <div className="text-[10px] text-[#191A23]/80 font-mono font-black uppercase tracking-widest mt-2">Hackers Applied</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black text-[#191A23] font-mono bg-[#191A23]/5 px-2 py-0.5 rounded-md border border-[#191A23] inline-block shadow-[1.5px_1.5px_0px_#191A23]">30+</div>
              <div className="text-[10px] text-[#191A23]/80 font-mono font-black uppercase tracking-widest mt-2">Elite Mentors</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black text-[#191A23] font-mono bg-[#191A23]/5 px-2 py-0.5 rounded-md border border-[#191A23] inline-block shadow-[1.5px_1.5px_0px_#191A23]">₹1.5L</div>
              <div className="text-[10px] text-[#191A23]/80 font-mono font-black uppercase tracking-widest mt-2">Prizes / Swag</div>
            </div>
          </motion.div>
        </div>

        {/* Vector Line-art Illustration Column (Right) */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="lg:col-span-5 flex justify-center items-center relative"
        >
          {/* Subtle floating dot grid background */}
          <div className="absolute inset-0 bg-[radial-gradient(#191A23_1px,transparent_1px)] [background-size:16px_16px] opacity-[0.07] pointer-events-none" />

          {/* Interactive illustration box. Custom hand-drawn neo-brutalist tech theme SVG */}
          <div className="relative w-full max-w-[380px] bg-[#191A23] border-4 border-[#B9FF66] rounded-[40px] p-6 shadow-[12px_12px_0px_#B9FF66] aspect-square flex items-center justify-center select-none overflow-hidden group">
            {/* Pulsing orbit glows inside vector box */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-[#B9FF66]/20 bg-[#B9FF66]/5 animate-pulse" />

            <svg
              viewBox="0 0 400 400"
              className="w-full h-full fill-none stroke-[#B9FF66] stroke-[3]"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {/* Stars & Sparks */}
              <path d="M50 80 Q55 70 60 80 Q55 90 50 80 Z" fill="#B9FF66" className="animate-pulse" />
              <path d="M330 110 Q335 100 340 110 Q335 120 330 110 Z" fill="#FFFFFF" stroke="#FFFFFF" className="animate-bounce" />
              <path d="M80 320 Q85 315 90 320 Q85 325 80 320 Z" fill="#B9FF66" />

              {/* Orbit Ellipse */}
              <ellipse cx="200" cy="200" rx="150" ry="60" strokeDasharray="8,8" className="animate-[spin_40s_linear_infinite]" />

              {/* Laptop & Terminal Block Center */}
              <rect x="110" y="180" width="180" height="110" rx="16" fill="#191A23" stroke="#FFFFFF" strokeWidth={4} />
              <rect x="125" y="195" width="150" height="80" rx="8" fill="#191A23" stroke="#B9FF66" strokeWidth={2} />
              
              {/* Content mock code inside laptop screen */}
              <polyline points="140,215 150,225 140,235" stroke="#B9FF66" strokeWidth={3} />
              <line x1="160" y1="235" x2="190" y2="235" stroke="#FFFFFF" strokeWidth={3} />
              <line x1="140" y1="255" x2="210" y2="255" stroke="#B9FF66" strokeWidth={3} />
              
              {/* Base/Keyboard frame of laptop */}
              <path d="M80 290 L320 290 C330 290 330 305 320 305 L80 305 C70 305 70 290 80 290 Z" fill="#191A23" stroke="#FFFFFF" strokeWidth={4} />
              <rect x="180" y="294" width="40" height="6" rx="2" fill="#B9FF66" />

              {/* Code Brackets floating */}
              <path d="M55 180 L40 195 L55 210" stroke="#FFFFFF" strokeWidth={4} />
              <path d="M345 180 L360 195 L345 210" stroke="#FFFFFF" strokeWidth={4} />

              {/* AI Robot Orb Floating */}
              <g className="animate-[bounce_3s_ease-in-out_infinite]">
                <circle cx="300" cy="110" r="30" fill="#191A23" stroke="#B9FF66" strokeWidth={4} />
                <rect x="285" y="105" width="30" height="10" rx="4" fill="#B9FF66" />
                <circle cx="293" cy="110" r="2.5" fill="#191A23" />
                <circle cx="307" cy="110" r="2.5" fill="#191A23" />
                <path d="M295 120 Q300 124 305 120" stroke="#FFFFFF" />
                {/* Antenna */}
                <line x1="300" y1="80" x2="300" y2="68" stroke="#FFFFFF" />
                <circle cx="300" cy="68" r="4" fill="#B9FF66" />
              </g>

              {/* Launching Rocket vector */}
              <g className="animate-[translate_4s_ease-in-out_infinite]">
                {/* Body */}
                <path d="M180 140 C180 80 200 40 200 40 C200 40 220 80 220 140 Z" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth={3} />
                {/* Window */}
                <circle cx="200" cy="95" r="8" fill="#191A23" stroke="#B9FF66" strokeWidth={2.5} />
                {/* Wings */}
                <path d="M180 120 L165 145 L180 145 Z" fill="#B9FF66" stroke="#191A23" strokeWidth={2} />
                <path d="M220 120 L235 145 L220 145 Z" fill="#B9FF66" stroke="#191A23" strokeWidth={2} />
                {/* Propulsion fire flame */}
                <path d="M190 144 L200 160 L210 144 Z" fill="#FF5E5E" />
              </g>
            </svg>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
