import { useState } from 'react';
import { Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  onRegisterClick: () => void;
}

export default function Navbar({ onRegisterClick }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Tracks', href: '#tracks' },
    { label: 'Schedule', href: '#schedule' },
    { label: 'Prizes', href: '#prizes' },
    { label: 'Videos', href: '#product-videos' },
    { label: 'Mentors', href: '#mentors' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <nav className="fixed top-0 left-0 w-full z-40 bg-white border-b-3 border-[#191A23] py-4 px-4 md:px-8">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-2 group cursor-pointer">
          <div className="bg-[#B9FF66] text-[#191A23] font-mono font-black text-xl px-3.5 py-1.5 border-3 border-[#191A23] rounded-xl shadow-[3px_3px_0px_#191A23] group-hover:translate-x-[-1px] group-hover:translate-y-[-1px] group-hover:shadow-[4px_4px_0px_#191A23] transition-all">
            HF
          </div>
          <span className="font-sans font-black text-2xl tracking-tight text-[#191A23] select-none">
            HackForge
          </span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-4 bg-white border-2 border-[#191A23] px-5 py-2.5 rounded-full shadow-[2.5px_2.5px_0px_#191A23]">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-xs uppercase font-black text-[#191A23] hover:bg-[#B9FF66] px-2.5 py-1 rounded-lg border border-transparent hover:border-[#191A23] transition-all"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Desktop Action Button */}
        <div className="hidden md:block">
          <button
            id="nav-register-btn"
            type="button"
            onClick={onRegisterClick}
            className="neo-btn px-5 py-2.5 text-sm uppercase flex items-center gap-1.5 cursor-pointer"
          >
            Register <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          id="nav-mobile-toggle"
          type="button"
          onClick={() => setMobileMenuOpen(prev => !prev)}
          className="md:hidden bg-white text-[#191A23] p-2 border-2 border-[#191A23] rounded-xl shadow-[2px_2px_0px_#191A23] active:translate-y-0.5 cursor-pointer transition-all"
          aria-label="Toggle Navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div id="mobile-menu-drawer" className="md:hidden absolute top-full left-0 w-full bg-white border-b-3 border-[#191A23] py-6 px-6 shadow-xl flex flex-col gap-5">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-lg font-black text-[#191A23] hover:text-[#B9FF66] border-b border-[#191A23]/10 pb-2 transition-all"
              >
                {link.label}
              </a>
            ))}
          </div>
          <button
            id="nav-mobile-register-btn"
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              onRegisterClick();
            }}
            className="neo-btn w-full py-3.5 text-center uppercase text-sm block cursor-pointer"
          >
            Register for HackForge
          </button>
        </div>
      )}
    </nav>
  );
}
