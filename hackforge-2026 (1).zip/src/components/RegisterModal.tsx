import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, ArrowRight, Sparkles, User, Mail, Users, Code, Github } from 'lucide-react';
import { Registration } from '../types';
import { TRACKS } from '../data';

interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisterSuccess: (reg: Registration) => void;
}

export default function RegisterModal({ isOpen, onClose, onRegisterSuccess }: RegisterModalProps) {
  const [formData, setFormData] = useState<Registration>({
    teamName: '',
    leaderName: '',
    leaderEmail: '',
    teamSize: 4,
    track: 'Artificial Intelligence',
    experienceLevel: 'Intermediate',
    githubUrl: '',
    agreeToCodeOfConduct: false,
  });

  const [errors, setErrors] = useState<Partial<Record<keyof Registration, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState(1);

  const validateStep = (currentStep: number) => {
    const newErrors: Partial<Record<keyof Registration, string>> = {};
    
    if (currentStep === 1) {
      if (!formData.teamName.trim()) newErrors.teamName = 'Team name is required';
      if (!formData.leaderName.trim()) newErrors.leaderName = 'Leader name is required';
      if (!formData.leaderEmail.trim()) {
        newErrors.leaderEmail = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(formData.leaderEmail)) {
        newErrors.leaderEmail = 'Please provide a valid email';
      }
    } else if (currentStep === 2) {
      if (!formData.track) newErrors.track = 'Please select a hack track';
    } else if (currentStep === 3) {
      if (!formData.agreeToCodeOfConduct) {
        newErrors.agreeToCodeOfConduct = 'You must agree to the Code of Conduct';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(3)) return;

    setSubmitting(true);
    
    // Simulate API registration call
    setTimeout(() => {
      setSubmitting(false);
      onRegisterSuccess(formData);
      // Reset form
      setFormData({
        teamName: '',
        leaderName: '',
        leaderEmail: '',
        teamSize: 4,
        track: 'Artificial Intelligence',
        experienceLevel: 'Intermediate',
        githubUrl: '',
        agreeToCodeOfConduct: false,
      });
      setStep(1);
    }, 1200);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (name === 'teamSize') {
      setFormData(prev => ({ ...prev, [name]: parseInt(value, 10) }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }

    if (errors[name as keyof Registration]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div id="register-portal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          id="register-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-[#191A23]/90 backdrop-blur-md"
        />

        {/* Modal Box */}
        <motion.div
          id="register-card"
          initial={{ scale: 0.95, y: 20, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.95, y: 20, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="relative w-full max-w-lg bg-white text-[#191A23] border-4 border-[#191A23] rounded-[32px] shadow-[8px_8px_0px_#B9FF66] p-6 md:p-8 overflow-hidden z-10"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6 border-b-2 border-[#191A23]/10 pb-4">
            <div>
              <span className="bg-[#B9FF66] text-[#191A23] font-mono font-bold text-xs px-2.5 py-1 border-2 border-[#191A23] rounded-md shadow-[2px_2px_0px_#191A23] tracking-wide inline-block mb-1.5 uppercase">
                Step {step} of 3
              </span>
              <h2 className="text-2xl font-black tracking-tight font-sans">
                {step === 1 && 'Hacker Core Info'}
                {step === 2 && 'Build Alignment'}
                {step === 3 && 'Final Verification'}
              </h2>
            </div>
            <button
              id="close-modal-btn"
              onClick={onClose}
              className="p-1.5 hover:bg-[#F3F3F3] border-2 border-[#191A23] rounded-lg shadow-[2px_2px_0px_#191A23] transition-all"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form id="registration-form" onSubmit={handleSubmit} className="space-y-5">
            {step === 1 && (
              <div className="space-y-4">
                {/* Team Name */}
                <div className="space-y-1">
                  <label htmlFor="teamName" className="font-bold text-sm tracking-wide block">
                    Team Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#191A23]/50" />
                    <input
                      id="teamName"
                      type="text"
                      name="teamName"
                      value={formData.teamName}
                      onChange={handleChange}
                      placeholder="e.g. ByteForge"
                      className="w-full text-sm font-medium border-2 border-[#191A23] bg-[#F3F3F3] pl-11 pr-4 py-2.5 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#B9FF66]/50 transition-all font-mono"
                    />
                  </div>
                  {errors.teamName && (
                    <span className="text-xs text-red-600 font-bold block">{errors.teamName}</span>
                  )}
                </div>

                {/* Team Leader Name */}
                <div className="space-y-1">
                  <label htmlFor="leaderName" className="font-bold text-sm tracking-wide block">
                    Leader Full Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#191A23]/50" />
                    <input
                      id="leaderName"
                      type="text"
                      name="leaderName"
                      value={formData.leaderName}
                      onChange={handleChange}
                      placeholder="e.g. Rahul Nair"
                      className="w-full text-sm font-medium border-2 border-[#191A23] bg-[#F3F3F3] pl-11 pr-4 py-2.5 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#B9FF66]/50 transition-all"
                    />
                  </div>
                  {errors.leaderName && (
                    <span className="text-xs text-red-600 font-bold block">{errors.leaderName}</span>
                  )}
                </div>

                {/* Team Leader Email */}
                <div className="space-y-1">
                  <label htmlFor="leaderEmail" className="font-bold text-sm tracking-wide block">
                    Leader Email Address <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#191A23]/50" />
                    <input
                      id="leaderEmail"
                      type="email"
                      name="leaderEmail"
                      value={formData.leaderEmail}
                      onChange={handleChange}
                      placeholder="e.g. rahul@example.com"
                      className="w-full text-sm font-medium border-2 border-[#191A23] bg-[#F3F3F3] pl-11 pr-4 py-2.5 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#B9FF66]/50 transition-all font-mono"
                    />
                  </div>
                  {errors.leaderEmail && (
                    <span className="text-xs text-red-600 font-bold block">{errors.leaderEmail}</span>
                  )}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                {/* Choose Track */}
                <div className="space-y-1">
                  <label htmlFor="track" className="font-bold text-sm tracking-wide block">
                    Target Innovation Track <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="track"
                    name="track"
                    value={formData.track}
                    onChange={handleChange}
                    className="w-full text-sm font-bold border-2 border-[#191A23] bg-[#F3F3F3] p-3 rounded-xl focus:outline-none focus:bg-white transition-all cursor-pointer"
                  >
                    {TRACKS.map(t => (
                      <option key={t.id} value={t.title}>
                        {t.title}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Team Size */}
                <div className="space-y-1">
                  <label className="font-bold text-sm tracking-wide block">
                    Team Members (Including yourself)
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4].map(size => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, teamSize: size }))}
                        className={`flex-1 py-3 font-mono font-black text-center border-2 border-[#191A23] rounded-xl transition-all cursor-pointer ${
                          formData.teamSize === size
                            ? 'bg-[#B9FF66] shadow-[2px_2px_0px_#191A23] scale-[1.02]'
                            : 'bg-[#F3F3F3] hover:bg-[#e4e4e4]'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Experience Level */}
                <div className="space-y-1">
                  <label className="font-bold text-sm tracking-wide block">
                    Experience Level
                  </label>
                  <div className="flex flex-col gap-1.5">
                    {['Beginner (First-time Hack)', 'Intermediate (Tinkerer)', 'Elite (Fierce Hacker)'].map(level => (
                      <button
                        key={level}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, experienceLevel: level.split(' ')[0] }))}
                        className={`text-left text-xs font-semibold p-2.5 border-2 border-[#191A23] rounded-xl w-full transition-all flex items-center justify-between cursor-pointer ${
                          formData.experienceLevel === level.split(' ')[0]
                            ? 'bg-[#B9FF66] font-extrabold border-[#191A23] shadow-[2px_2px_0px_#191A23]'
                            : 'bg-white hover:bg-[#F3F3F3]'
                        }`}
                      >
                        <span>{level}</span>
                        {formData.experienceLevel === level.split(' ')[0] && (
                          <Check className="w-3.5 h-3.5" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                {/* GitHub link */}
                <div className="space-y-1">
                  <label htmlFor="githubUrl" className="font-bold text-sm tracking-wide block">
                    Github Group or Personal Handle <span className="text-[#191A23]/50 font-normal">(Optional)</span>
                  </label>
                  <div className="relative">
                    <Github className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#191A23]/50" />
                    <input
                      id="githubUrl"
                      type="text"
                      name="githubUrl"
                      value={formData.githubUrl}
                      onChange={handleChange}
                      placeholder="e.g. github.com/rahulmenon"
                      className="w-full text-sm font-medium border-2 border-[#191A23] bg-[#F3F3F3] pl-11 pr-4 py-2.5 rounded-xl focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#B9FF66]/50 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Agreement Panel */}
                <div className="bg-[#F3F3F3] border-2 border-[#191A23]/20 p-3.5 rounded-2xl text-[11px] leading-relaxed text-[#191A23]/80 space-y-2">
                  <p className="font-bold text-[#191A23]">Code of Conduct Agreement:</p>
                  <p>
                    I agree to contribute constructively, communicate respectfully in developer spaces, collaborate honorably, and present strictly original prototypes crafted within the 48-hour sprints of HackForge 2026.
                  </p>
                </div>

                {/* Checkbox */}
                <div className="flex items-start gap-2.5">
                  <input
                    id="agreeToCodeOfConduct"
                    type="checkbox"
                    name="agreeToCodeOfConduct"
                    checked={formData.agreeToCodeOfConduct}
                    onChange={handleChange}
                    className="mt-1 cursor-pointer w-4 h-4 accent-[#B9FF66] border-2 border-[#191A23] rounded "
                  />
                  <label htmlFor="agreeToCodeOfConduct" className="text-xs font-bold leading-tight cursor-pointer">
                    I accept the above Code of Conduct and register.
                  </label>
                </div>
                {errors.agreeToCodeOfConduct && (
                  <span className="text-xs text-red-600 font-bold block">{errors.agreeToCodeOfConduct}</span>
                )}
              </div>
            )}

            {/* Actions Footer */}
            <div className="flex gap-3 pt-6 border-t-2 border-[#191A23]/10 mt-6">
              {step > 1 && (
                <button
                  type="button"
                  onClick={handleBack}
                  className="flex-1 py-3 text-sm font-bold border-2 border-[#191A23] rounded-xl hover:bg-[#F3F3F3] active:translate-y-0.5 transition-all cursor-pointer"
                >
                  Back
                </button>
              )}
              {step < 3 ? (
                <button
                  type="button"
                  onClick={handleNext}
                  className="flex-1 py-3 text-sm font-black bg-[#B9FF66] text-[#191A23] border-2 border-[#191A23] rounded-xl shadow-[4px_4px_0px_#191A23] hover:-translate-x-0.5 hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_#191A23] transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  Continue <ArrowRight className="w-4 h-4 animate-pulse" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-3 text-sm font-black bg-[#B9FF66] text-[#191A23] border-2 border-[#191A23] rounded-xl shadow-[4px_4px_0px_#191A23] hover:-translate-x-0.5 hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_#191A23] active:translate-x-0 active:translate-y-0 transition-all flex items-center justify-center gap-2 disabled:bg-opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  {submitting ? (
                    <span className="flex items-center gap-1.5 font-mono">
                      FORGING TICKET...
                    </span>
                  ) : (
                    <>
                      Complete Booking <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
