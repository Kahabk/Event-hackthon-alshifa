import { useRef, useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';

interface VideoItem {
  id: string;
  src: string;
  title: string;
  description: string;
  tag: string;
}

const VIDEOS: VideoItem[] = [
  {
    id: 'kamludeen',
    src: '/kamludeen.mp4',
    title: 'Hardware Forge Lab',
    description: 'Calicut builders assembling IoT interfaces, smart boards, and hardware modules at HackForge.',
    tag: 'BUILD',
  },
  {
    id: 'startup',
    src: '/startup.mp4',
    title: 'Demo Pitch Stage',
    description: 'Teams showcasing decentralized neural-net agents and rapid API prototypes to the jury panel.',
    tag: 'PITCH',
  },
  {
    id: 'girl',
    src: '/girl.mp4',
    title: 'Immersive Realities',
    description: 'Visual developers calibrating gestural inputs and designing spatial tracking applications.',
    tag: 'INNOVATE',
  },
];

function SingleVideoPlayer({ video }: { video: VideoItem; key?: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loopCount, setLoopCount] = useState(1);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch((err) => {
        console.log('Autoplay deferred:', err);
      });
    }
  }, []);

  const handleEnded = () => {
    if (loopCount < 2) {
      setLoopCount((prev) => prev + 1);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch((err) => {
          console.error('Play loop 2 error:', err);
        });
      }
    }
  };

  return (
    <div className="w-full overflow-hidden rounded-[28px] sm:rounded-[36px] bg-[#191A23] aspect-[16/10] sm:aspect-[16/9]">
      <video
        ref={videoRef}
        src={video.src}
        className="w-full h-full object-cover"
        muted
        playsInline
        autoPlay
        onEnded={handleEnded}
      />
    </div>
  );
}

export default function ProductVideos() {
  return (
    <section id="product-videos" className="py-12 md:py-16 px-4 md:px-8 bg-white text-[#191A23] border-b-3 border-[#191A23]">
      <div className="max-w-3xl mx-auto space-y-10">
        {/* Section Header */}
        <div className="text-left space-y-2">
          <h2 id="videos-heading" className="text-3xl sm:text-4xl font-black tracking-tight text-[#191A23]">
            Product Videos
          </h2>
        </div>

        {/* Clean, borderless, buttonless vertical stack list */}
        <div className="flex flex-col gap-6">
          {VIDEOS.map((video) => (
            <SingleVideoPlayer key={video.id} video={video} />
          ))}
        </div>
      </div>
    </section>
  );
}
