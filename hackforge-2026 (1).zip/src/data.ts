import { Track, Highlight, DaySchedule, Prize, Mentor, Testimonial, FAQItem } from './types';

export const SPONSORS = [
  { name: 'Google Developer Groups', logoText: 'GDG' },
  { name: 'GitHub', logoText: 'GitHub' },
  { name: 'Notion', logoText: 'Notion' },
  { name: 'Figma', logoText: 'Figma' },
  { name: 'Vercel', logoText: 'Vercel' },
  { name: 'OpenAI', logoText: 'OpenAI' }
];

export const HIGHLIGHTS: Highlight[] = [
  {
    id: 'highlight-1',
    title: '48 Hour Build Sprint',
    description: 'Race against time to bring your boldest ideas to life. Code, design, and pitch in 48 uninterrupted hours.',
    iconName: 'Timer',
    color: 'white'
  },
  {
    id: 'highlight-2',
    title: 'AI & Web3 Challenges',
    description: 'Solve frontier problems with access to premium APIs, developer credits, and advanced developer resources.',
    iconName: 'Cpu',
    color: 'green'
  },
  {
    id: 'highlight-3',
    title: 'Expert Mentors',
    description: 'Receive real-time architectural feedback from top industry engineers, startup founders, and design leads.',
    iconName: 'MessagesSquare',
    color: 'black'
  },
  {
    id: 'highlight-4',
    title: 'Startup Networking',
    description: 'Pitch to real VCs, angel investors, and accelerators. Turn your hackathon prototype into a funded venture.',
    iconName: 'Network',
    color: 'green'
  },
  {
    id: 'highlight-5',
    title: 'Live Demos',
    description: 'No slides-only pitches. Demo your working code live in front of our technical jury and hundreds of peers.',
    iconName: 'Tv',
    color: 'black'
  },
  {
    id: 'highlight-6',
    title: 'Cash Prizes',
    description: 'Win from a pool of cash awards, exclusive internship pathways, and enterprise developer grants.',
    iconName: 'Coins',
    color: 'white'
  }
];

export const TRACKS: Track[] = [
  {
    id: 'track-ai',
    title: 'Artificial Intelligence',
    iconName: 'BrainCircuit',
    description: 'Push the limits of generative models, autonomous agents, and intelligence layers.',
    challenges: [
      'Solve domain-specific problems using Generative AI models and LLMs',
      'Build specialized multi-agent systems with collaborative task flows',
      'Optimize neural architectures for low-resource or offline environments'
    ],
    color: 'green'
  },
  {
    id: 'track-webdev',
    title: 'Web Development',
    iconName: 'Terminal',
    description: 'Craft high-performance, accessible, and delightful modern web applications.',
    challenges: [
      'Design rich, microkernel-based or pluggable web architectures',
      'Implement offline-first client syncing or high-velocity collaborative workspaces',
      'Achieve flawless performance metrics with sub-second page loads'
    ],
    color: 'white'
  },
  {
    id: 'track-robotics',
    title: 'Robotics & IoT',
    iconName: 'Bot',
    description: 'Bridge software and physical spaces through smart hardware systems and controllers.',
    challenges: [
      'Program hardware microcontrollers and peripheral sensory models',
      'Develop edge computing AI nodes for predictive environmental control',
      'Create reactive safety systems with ultra-low signal latency'
    ],
    color: 'white'
  },
  {
    id: 'track-fintech',
    title: 'FinTech',
    iconName: 'TrendingUp',
    description: 'Unlock decentralized ledgers, banking APIs, or accessible payment microservices.',
    challenges: [
      'Construct security-hardened transaction pipelines or smart contracts',
      'Model predictive credit systems using alternative data indexing',
      'Architect micro-payment layers with optimal capital routing mechanics'
    ],
    color: 'white'
  },
  {
    id: 'track-climate',
    title: 'Climate Tech',
    iconName: 'Leaf',
    description: 'Pioneer green technologies to track or reduce carbon emissions and optimize resources.',
    challenges: [
      'Develop open-source hardware controllers to monitor real-time carbon outputs',
      'Design local trading platforms for decentralized energy systems',
      'Optimize micro-routing algorithms for circular supply logistics'
    ],
    color: 'white'
  },
  {
    id: 'track-open',
    title: 'Open Innovation',
    iconName: 'Lightbulb',
    description: 'Let your creativity fly. Solve any real-world problem without boundaries.',
    challenges: [
      'Identify critical friction points in daily enterprise or healthcare systems',
      'Validate highly novel interaction paradigms or tool loops',
      'Build highly maintainable utility services that empower public accessibility'
    ],
    color: 'white'
  }
];

export const SCHEDULE: DaySchedule[] = [
  {
    day: 'Day 1',
    date: 'Friday, Oct 23',
    items: [
      {
        time: '14:00 - 16:00',
        title: 'Check-In & Badge Collection',
        description: 'Verify your registrations, collect your custom HackForge NFC badges, and secure your team cabins.',
        category: 'event'
      },
      {
        time: '17:00 - 18:00',
        title: 'Opening Ceremony',
        description: 'Keynotes from technology advocates, introduction of the jury, and grand reveal of specialized API challenges.',
        category: 'ceremony'
      },
      {
        time: '18:00 - 19:00',
        title: 'Team Formation & Mixer',
        description: 'Don\'t have a team? Meet top engineers and designers in our matching area with icebreakers.',
        category: 'event'
      },
      {
        time: '19:30',
        title: 'Hacking Begins!',
        description: 'The clock starts. Brainstorming, architectural planning, and repo initializations are officially underway.',
        category: 'hacking'
      }
    ]
  },
  {
    day: 'Day 2',
    date: 'Saturday, Oct 24',
    items: [
      {
        time: '09:00 - 11:30',
        title: 'Mentor Review: Round I',
        description: 'Present your early wireframes and architectural schemas to technical mentors for validation and code pivot strategies.',
        category: 'mentoring'
      },
      {
        time: '14:00 - 15:30',
        title: 'Tech Talk: Advanced Agentic Workflows',
        description: 'An optional masterclass by OpenAI and Google engineers detailing high-throughput orchestration paradigms.',
        category: 'event'
      },
      {
        time: '19:00 - 21:00',
        title: 'Mentor Review: Round II',
        description: 'Verify functional integrations. Code reviews, payload optimization checks, and prototype run tests.',
        category: 'mentoring'
      },
      {
        time: '23:00',
        title: 'Midnight Pitch Practice & Snack',
        description: 'Hone your pitch flow. Give a 60-second elevator feedback trial to design judges and unlock brain-health snacks.',
        category: 'event'
      }
    ]
  },
  {
    day: 'Day 3',
    date: 'Sunday, Oct 25',
    items: [
      {
        time: '12:00',
        title: 'Final Code Submission',
        description: 'Hacking freezes. Submit your repository links, video walkthroughs, and deployment endpoints for initial filtration.',
        category: 'hacking'
      },
      {
        time: '13:30 - 16:00',
        title: 'Demo Day & Live Judging',
        description: 'Top 10 finalists present their working code live on stage in front of the technical jury panel and VC judges.',
        category: 'ceremony'
      },
      {
        time: '16:30 - 17:30',
        title: 'Winner Announcements',
        description: 'Awarding the cash prizes, physical trophies, premium creator credits, and exclusive internships.',
        category: 'ceremony'
      }
    ]
  }
];

export const PRIZES: Prize[] = [
  {
    place: '2nd Prize',
    amount: '₹25,000',
    rewards: [
      'Physical Silver Forge Medal',
      'Premium Swag Kits (Custom hoodies & keycaps)',
      '₹50,000 Cloud Platform Credits',
      'Exclusive placement invitation'
    ],
    color: 'white',
    iconName: 'Medal'
  },
  {
    place: '1st Prize',
    amount: '₹50,000',
    rewards: [
      'Grand HackForge 2026 Rotating Trophy',
      'Exclusive Fast-Track Interview Pathways',
      '₹1,00,000 developer cloud workspace grants',
      '1-on-1 mentorship by startup accelerator directors'
    ],
    color: 'black',
    iconName: 'Trophy'
  },
  {
    place: '3rd Prize',
    amount: '₹10,000',
    rewards: [
      'Physical Bronze Forge Medal',
      'Sponsor mystery boxes and IoT kits',
      'Verification Certificates of Excellence',
      'Direct admission to startup circles'
    ],
    color: 'green',
    iconName: 'Award'
  }
];

export const MENTORS: Mentor[] = [
  {
    name: 'Aisha Khan',
    role: 'AI Engineer',
    description: 'Expert in LLM fine-tuning, retrieval setups, and multi-agent systems. Formerly at DeepMind.',
    linkedin: 'https://linkedin.com',
    colorClass: 'bg-emerald-100',
    techStack: ['PyTorch', 'Gemini APIs', 'LangChain', 'FastAPI']
  },
  {
    name: 'Rahul Menon',
    role: 'Startup Founder',
    description: 'Two-time fintech founder. Specialized in business model validation, seed pitching, and APIs.',
    linkedin: 'https://linkedin.com',
    colorClass: 'bg-indigo-100',
    techStack: ['Product Strategy', 'SaaS Scaling', 'Venture Capital']
  },
  {
    name: 'Priya Nair',
    role: 'Product Designer',
    description: 'Aesthetic lead crafting interactive human-computer systems. Specialized in design systems.',
    linkedin: 'https://linkedin.com',
    colorClass: 'bg-pink-100',
    techStack: ['Figma', 'Prototyping', 'Design Systems', 'UX Research']
  },
  {
    name: 'Arjun Das',
    role: 'Full Stack Developer',
    description: 'Production engineer focusing on heavy traffic WebSockets, distributed databases, and security.',
    linkedin: 'https://linkedin.com',
    colorClass: 'bg-amber-100',
    techStack: ['Next.js', 'Node.js', 'PostgreSQL', 'Docker']
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    text: '“Best hackathon experience I ever had. The mentors helped us convert a raw whiteboard drawing into a working, deployed MVP in just 48 hours.”',
    author: 'Samarth Joshi',
    role: 'Tech Lead',
    team: 'Team NeuroForge (AI Track Winners 2025)'
  },
  {
    text: '“HackForge gave us the courage and peer feedback to pitch our product in front of real investors. We secured a pre-seed term sheet within a month!”',
    author: 'Devika Ramachandran',
    role: 'Founder',
    team: 'Team EcoSifter (Climate Tech Winner 2025)'
  }
];

export const FAQS: FAQItem[] = [
  {
    question: 'Who can participate?',
    answer: 'Any student, professional, researcher, developer, designer, or builder who is eager to build awesome things! Whether you are a college freshman writing your first APIs or a senior staff engineer tinkering with LLMs, you are welcome.'
  },
  {
    question: 'Do I need a team?',
    answer: 'While you can work solo, we highly recommend collaborating in teams of 2 to 4 members. If you don\'t have a team yet, we will host active networking sessions and team mixers on Friday (Day 1) to match you with compatible partners.'
  },
  {
    question: 'Is it free to register?',
    answer: 'Yes, register is 100% free! Food, carbonated drinks, power, internet access, sleeping areas, and developer API credits are sponsored entirely by our incredible partners.'
  },
  {
    question: 'What should I bring with me?',
    answer: 'Bring your laptop, charger/extension cords, personal hygiene kits, comfortable clothes, and a drive to build. Sleeping pads and pillows will be provided in our dedicated relaxation docks.'
  },
  {
    question: 'Will food be provided throughout?',
    answer: 'Absolutely! We will supply four complete hot meals, fresh automated breakfast counters, midnight pizza slots, high-quality snacks, and plenty of coffee/energy drinks throughout the entire event.'
  },
  {
    question: 'How are winners selected?',
    answer: 'Submissions are assessed out of 100 points across four equal criteria: Technical execution (working, bug-free codebase), Innovation (how original and clever is the concept), Design and UX (fluidity, aesthetic fidelity), and Potential Impact/Pitch (can this work in the real-world scale).'
  }
];
