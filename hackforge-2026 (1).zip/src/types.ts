export interface Track {
  id: string;
  title: string;
  iconName: string;
  description: string;
  challenges: string[];
  color: 'green' | 'white' | 'black';
}

export interface Highlight {
  id: string;
  title: string;
  description: string;
  iconName: string;
  color: 'white' | 'green' | 'black';
}

export interface ScheduleItem {
  time: string;
  title: string;
  description: string;
  category: 'ceremony' | 'hacking' | 'mentoring' | 'event';
}

export interface DaySchedule {
  day: string;
  date: string;
  items: ScheduleItem[];
}

export interface Prize {
  place: string;
  amount: string;
  rewards: string[];
  color: 'white' | 'black' | 'green';
  iconName: string;
}

export interface Mentor {
  name: string;
  role: string;
  description: string;
  linkedin: string;
  colorClass: string;
  techStack: string[];
}

export interface Testimonial {
  text: string;
  author: string;
  role: string;
  team: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Registration {
  teamName: string;
  leaderName: string;
  leaderEmail: string;
  teamSize: number;
  track: string;
  experienceLevel: string;
  githubUrl?: string;
  agreeToCodeOfConduct: boolean;
}
