/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, CheckCircle2, Ticket, ArrowRight, ShieldCheck } from 'lucide-react';

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Sponsors from './components/Sponsors';
import Highlights from './components/Highlights';
import Tracks from './components/Tracks';
import Schedule from './components/Schedule';
import Prizes from './components/Prizes';
import ProductVideos from './components/ProductVideos';
import PassportGenerator from './components/PassportGenerator';
import Mentors from './components/Mentors';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import CTA from './components/CTA';
import Footer from './components/Footer';
import RegisterModal from './components/RegisterModal';
import { Registration } from './types';

export default function App() {
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [registrationDetail, setRegistrationDetail] = useState<Registration | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const handleRegisterSuccess = (registration: Registration) => {
    setRegistrationDetail(registration);
    setIsRegisterModalOpen(false);
    setShowSuccessToast(true);

    // Dynamic pleasant auto-scroll to passport generator section
    setTimeout(() => {
      const targetSec = document.getElementById('passport-forge-arena');
      if (targetSec) {
        targetSec.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 1500);

    // Dismiss overlay success toast after 6 seconds
    setTimeout(() => {
      setShowSuccessToast(false);
    }, 6000);
  };

  return (
    <div className="min-h-screen bg-white text-[#191A23] overflow-x-hidden font-sans antialiased custom-scrollbar selection:bg-[#B9FF66] selection:text-[#191A23]">
      {/* Dynamic Success notifications once booking completes */}
      <AnimatePresence>
        {showSuccessToast && registrationDetail && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4"
          >
            <div className="bg-[#B9FF66] border-4 border-[#191A23] p-5 rounded-[24px] shadow-[6px_6px_0px_white] text-[#191A23] space-y-3.5 relative">
              <div className="flex gap-3 items-start text-left">
                <CheckCircle2 className="w-6.5 h-6.5 text-[#191A23] fill-white flex-none" />
                <div className="space-y-1 min-w-0">
                  <h4 className="font-sans font-black text-lg tracking-tight">Hacker Slot Authenticated!</h4>
                  <p className="text-xs font-semibold leading-relaxed">
                    Congrats! Team <strong className="font-black">{registrationDetail.teamName}</strong> is logged. Scroll to Passport center to claim your builder credentials.
                  </p>
                </div>
              </div>

              {/* Action guide indicator */}
              <div className="bg-[#191A23] text-white text-[10px] p-2 rounded-xl flex items-center justify-between font-mono font-bold">
                <span className="flex items-center gap-1">
                  <Ticket className="w-3.5 h-3.5 text-[#B9FF66] fill-[#B9FF66]" /> ACTIVE PASSPORT REDEMPTIONS
                </span>
                <span className="animate-pulse text-[#B9FF66] flex items-center gap-1.5 cursor-pointer" onClick={() => setShowSuccessToast(false)}>
                  Close <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Primary headers */}
      <Navbar onRegisterClick={() => setIsRegisterModalOpen(true)} />

      {/* Landing Sectors Stack */}
      <main>
        {/* Hero Banner Section */}
        <Hero onRegisterClick={() => setIsRegisterModalOpen(true)} />

        {/* Gray Global Sponsor Strip Section */}
        <Sponsors />

        {/* Why Join Highlight System Section */}
        <Highlights />

        {/* Interactive Tracks Accordion Section */}
        <Tracks />

        {/* Dynamic Schedule Calendar Tabs Section */}
        <Schedule />

        {/* Rewards grid Block Section */}
        <Prizes />

        {/* Dynamic Video Showcase Section */}
        <ProductVideos />

        {/* Custom Passport Badge Center (Dynamic ticket customizer module) */}
        <section id="passport-forge-arena" className="py-20 md:py-28 px-4 md:px-8 bg-[#F3F3F3] border-b-3 border-[#191A23] relative">
          <div className="absolute top-1/4 right-3 w-72 h-72 bg-[#191A23]/5 rounded-full blur-[110px] pointer-events-none" />
          
          <div className="max-w-5xl mx-auto space-y-12 relative z-10">
            {/* Sector Header */}
            <div className="text-center space-y-3 max-w-xl mx-auto">
              <span className="bg-[#B9FF66] text-[#191A23] font-mono font-bold text-xs px-3.5 py-1.5 border-2 border-[#191A23] rounded-md shadow-[2px_2px_0px_#191A23] uppercase tracking-wider inline-block">
                Attendee Terminal
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight leading-tight text-[#191A23]">
                Hacker <span className="neo-highlight">Passport</span> Center
              </h2>
              <p className="text-[#191A23]/70 text-sm sm:text-base font-semibold leading-relaxed">
                {registrationDetail 
                  ? 'Complete validation. Claim and style your cryptographic physical or virtual arena access passport badge below.'
                  : 'Forge a prototype pass. Try customizing credentials, select visual characters, and print your developer ticket.'}
              </p>
            </div>

            {/* Passport customization card blocks wrapper */}
            <div className="pt-2">
              <PassportGenerator 
                initialName={registrationDetail?.leaderName} 
                initialTrack={registrationDetail?.track} 
              />
            </div>
          </div>
        </section>

        {/* Expert advisers bios System Section */}
        <Mentors />

        {/* Quotes Testimonials Grid Section */}
        <Testimonials />

        {/* FAQ System Block Section */}
        <FAQ />

        {/* Visual Call To Action Section */}
        <CTA onRegisterClick={() => setIsRegisterModalOpen(true)} />
      </main>

      {/* Global standard Footer */}
      <Footer />

      {/* Animated Floating Modal Overlay portal trigger */}
      <RegisterModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
        onRegisterSuccess={handleRegisterSuccess}
      />
    </div>
  );
}

